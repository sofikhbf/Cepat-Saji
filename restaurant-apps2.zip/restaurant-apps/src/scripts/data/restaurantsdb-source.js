import API_ENDPOINT from '../globals/api-endpoint'

class RestDbSource {
  static async Homey () {
    const response = await fetch(API_ENDPOINT.LIST)
    const responseJson = await response.json()
    console.log(responseJson)
    return responseJson.restaurants
  }

  static async DETAIL (id) {
    const response = await fetch(API_ENDPOINT.DETAIL(id))
    return response.json()
  }

  static async reviewResto () {
    const response = await fetch(API_ENDPOINT.REVIEW)
    const responseJson = response.json()
    return responseJson
  }
}

export default RestDbSource
