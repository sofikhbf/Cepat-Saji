
import FavoriteRestaurantIdb from '../../data/favorite-restaurants-idb'
import { createRestaurantItemTemplate } from '../templates/template-creator'

const Favorite = {
  async render () {
    return `
    <section class="content">
    <div class="latest">
        <h1 tabindex="0">Pilihan Restaurant Favorite</h1>
        <div class="list" id="explore-restaurant"></div>
    </div>
</section>
    `
  },

  async afterRender () {
    const restaurants = await FavoriteRestaurantIdb.getAllRestaurant()
    const restaurantsContainer = document.querySelector('#explore-restaurant')

    restaurants.forEach((restaurant) => {
      restaurantsContainer.innerHTML += createRestaurantItemTemplate(restaurant)
    })
  }
}

export default Favorite
